#!/usr/bin/perl

require "../../LedgerSMB/locales.pl"
